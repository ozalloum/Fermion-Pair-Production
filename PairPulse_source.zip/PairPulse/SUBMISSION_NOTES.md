# Manuscript files

The manuscript is prepared for Physica Scripta. Its sources and figure files are together in `manuscript/`. The public repository presents the submission files in a flat directory and supplies this archive for computational reproduction.
