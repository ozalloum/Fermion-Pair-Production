PairPulse 0.2.2 source distribution. See Computational_materials/README.md and USER_GUIDE.txt. Numerical data and manuscript: https://github.com/ozalloum/Fermion-Pair-Production
