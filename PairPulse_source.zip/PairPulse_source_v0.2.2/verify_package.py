"""Verify this package's manifest using only the Python standard library."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
failures=[];count=0;listed=set()
for line in (root/'CHECKSUMS.sha256').read_text().splitlines():
    if not line.strip():continue
    digest,name=line.split(None,1);name=name.lstrip('* ');p=(root/name).resolve()
    if name in listed:failures.append('Duplicate manifest entry: '+name)
    listed.add(name)
    if not p.is_relative_to(root) or not p.is_file():failures.append('Missing/invalid: '+name)
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=digest:failures.append('Mismatch: '+name)
    count+=1
if failures:raise SystemExit('\n'.join(failures))
print(f'PASS: {count} files match the outer SHA-256 manifest')
