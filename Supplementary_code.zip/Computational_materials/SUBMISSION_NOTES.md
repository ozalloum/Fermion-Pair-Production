# Manuscript files

The anonymised manuscript and its figures are in `manuscript/`. This supplementary archive contains the source code, tests, notebook, and reproduction scripts for peer review. Generated datasets are produced by the commands in README.md.
