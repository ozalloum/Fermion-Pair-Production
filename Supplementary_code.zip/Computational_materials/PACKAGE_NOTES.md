# Manuscript files

The manuscript and its four figures are in `manuscript/`. The source uses the standard LaTeX article class. This archive contains the source code, tests, notebook, and reproduction scripts. Generated datasets are produced by the commands in README.md.
